package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.testprojet.R;

public class ChangePassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
    }
    public void SubmitP(View v){
        if(v.getId()==R.id.submitpsw){
            Intent swwitchSubP = new Intent(this,ManageAccount.class);
            startActivity(swwitchSubP);
        }
    }
}
