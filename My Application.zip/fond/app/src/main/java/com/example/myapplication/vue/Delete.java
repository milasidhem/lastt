package com.example.myapplication.vue;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.example.myapplication.controleur.Controle;
import com.example.testprojet.R;

public class Delete extends AppCompatActivity {
    Controle controle;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        controle.mine(controle.USER);
        controle.all();
        //Get that instance saved in the previous activity
        sharedPreferences = getSharedPreferences("autoLogin", Context.MODE_PRIVATE);
    }
    public void DeleteA(View v){
        if(v.getId()==R.id.deleteA){
            showAlert();
        }
   }

   public void showAlert(){
       AlertDialog.Builder alert = new AlertDialog.Builder(this);
       alert.setTitle("Confirmation");
       alert.setMessage("Are you sure you want to delete your account?");
       alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {
               SharedPreferences.Editor editor = sharedPreferences.edit();
               editor.putInt("key", 0);
               editor.apply();
               //delete
               controle.delUser(controle.USER);
               Intent delete = new Intent(Delete.this, Login.class);
               delete.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
               // Add new Flag to start new Activity
               delete.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
               startActivity(delete);
           }
       });
       alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {

           }
       });
       alert.create().show();
   }
}
