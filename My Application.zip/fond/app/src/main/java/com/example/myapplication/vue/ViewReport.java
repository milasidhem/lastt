package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Report;
import com.example.myapplication.outils.MesOutils;
import com.example.testprojet.R;

public class ViewReport extends AppCompatActivity {

    //proprietes
    private RelativeLayout relative;
    private TextView titletxt;
    private TextView usernametxt;
    private TextView desctxt;
    private TextView authtxt;
    private TextView datetxt;
    private ImageView imagereport;
    private Controle controler;
    private Report report;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_report);
        init();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_delete,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId()==R.id.delete){
            Intent intent = new Intent(this, HomePage.class);
            //notifyDataSetChanged();
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            // Add new Flag to start new Activity
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            controler.delReport(report);
            controler.mesRapports.clear();
            controler.all();
            controler.mine(controler.USER);
            Toast.makeText(ViewReport.this,"Report deleted",Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed(){
        Intent intent = new Intent(this, HomePage.class);
        startActivity(intent);
    }
    /**
     * initialization des liens avec les objet
     */
    private void init(){
        relative = findViewById(R.id.relative);
        titletxt = findViewById(R.id.titletxt);
        usernametxt = findViewById(R.id.usernametxt);
        desctxt = findViewById(R.id.desctxt);
        authtxt = findViewById(R.id.authtxt);
        datetxt = findViewById(R.id.datetxt);
        imagereport = findViewById(R.id.imagereport);
        relative = findViewById(R.id.relative);
        this.controler = Controle.getInstance(this);
        recupProfil();
    }
    public void recupProfil(){
        if(controler.getTitle()!=""){
            usernametxt.setText("shared by "+controler.USER);
            titletxt.setText(controler.getTitle());
            desctxt.setText(controler.getDescription());
            datetxt.setText(MesOutils.convertDateToString(controler.getDate1()));
            Integer etat = controler.getEtat();
            if(etat==1)relative.setBackgroundResource(R.drawable.red2);
            else if(etat==2)relative.setBackgroundResource(R.drawable.orange);
            else relative.setBackgroundResource(R.drawable.green2);
            // remettre à vide le profil
            report = this.controler.report;
            controler.setReport(null);
        }
    }
}
