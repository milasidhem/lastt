package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.testprojet.R;

public class ChangePhoneNumber extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_phone_number);
    }
    public void SubmitPH(View v){
        if(v.getId()==R.id.changeP){
            Intent swwitchSubPH = new Intent(this,ManageAccount.class);
            startActivity(swwitchSubPH);
        }
    }
}
