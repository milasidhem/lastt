package com.example.myapplication.vue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.controleur.Controle;
import com.example.myapplication.model.Report;
import com.example.testprojet.R;

import java.util.ArrayList;
import java.util.Collections;

public class ListReports extends AppCompatActivity {

    private Controle controle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_reports);
        this.controle = Controle.getInstance(this);
        this.controle.mine(controle.USER);
        controle.all();
        creerListe();
    }

    /**
     * créer la liste adapter
     */
    private void creerListe(){
        ArrayList<Report> mesRapports = controle.getMesRapports();
        Collections.sort(mesRapports, Collections.<Report>reverseOrder());
        if(mesRapports != null){
            ListView lsRep = findViewById(R.id.reportlist);
            ReportListAdapter adapter = new ReportListAdapter(this,mesRapports);
            lsRep.setAdapter(adapter);
        }
    }
    public void affichReport(Report report){
        controle.setReport(report);
        Intent intent = new Intent(this, ViewReport.class);
        startActivity(intent);
    }
}
